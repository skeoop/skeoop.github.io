package coinpurse;
//TODO fix this Javadoc. It should be written as a complete sentence.
/**
 * a coin with a monetary value
 * @author
 */
public class Coin {

    /** Value of the coin. */
    private double value;
    
    public Coin( double value ) {
        this.value = value;
    }

//TODO Write a getValue() method and javadoc.
    public double getValue( ) { return 0; }
//TODO Write an equals(Object) method.
//TODO Write a compareTo method and implement Comparable.
//TODO Write Javadoc comments on all methods.
    
}
//TODO remove the TODO comments after you complete them. Including this one!
