 
/**
 * A coin with a monetary value.
 * You can't change the value of a coin.
 * @author your name
 */
public class Coin {

    /** Value of the coin */
    private double value;
    
    /** 
     * Constructor for a new coin. 
     * @param value is the value for the coin
     */
    public Coin( double value ) {
        this.value = value;
    }

//TODO Write a getValue() method.
//TODO Write an equals(Object) method.
//TODO Write a compareTo method and implement Comparable.
//TODO Write Javadoc comments on all methods.
    
}
//TODO remove the TODO comments after you complete them. Including this one!
